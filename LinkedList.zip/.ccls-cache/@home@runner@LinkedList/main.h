#ifndef MAIN_H
#define MAIN_H

//Global variables
extern unsigned short time;

//Functions
struct Node *createNode(short time, double temperature);
void insertFirst(struct Node **list, struct Node *el);
int isMember(struct Node **list, struct Node *el);
void printList(struct Node *list);
void removes(struct Node **list, struct Node *el);
struct Node *readSensor(int id);
void NodeSort(struct Node **list);
void clearMemory(struct Node **list);
char isFull(struct Node **list);
void insertNode(struct Node **list, struct Node *el);
struct Node *findMax(struct Node **list);
struct Node *findMin(struct Node **list);
double findAvg(struct Node **list);


#endif