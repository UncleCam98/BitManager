#include "main.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//Global variables
unsigned short time = 0;

typedef struct Node {
    // short time; (binärt 4 hexa 0x0000 -> 0xhhmm) (1 << 12) [s  = 0000 0001 0000 0100 = 01:04]
    // (time >> 4) 0xf
    short tid; // data
    char temperature;
    struct Node *next; // pointer to the next element
}Node;

int size(Node *list) {
  int counter = 0;
  Node *temp = list;
  while (temp != NULL) {
    counter++;
    temp = temp->next;
  }
  return counter;
}

Node *createNode(short tid, char temperature) {
  Node *p = NULL;
  p = (Node *)malloc(sizeof(Node));
  if (p == NULL) {
    printf("Out of memory ! \n");
    return NULL;
  }

  p->tid = tid;
  p->temperature = temperature;
  p->next = NULL;
  return p;
  //“malloc” is used to dynamically allocate a single large block of memory with
  // the specified size. It returns a pointer of type void which can be cast
  // into a pointer of any form.
}



//*UPPGIFT 1b*//
int isMember(Node **list, Node *el) {
  Node *temp = *list;
  if (*list == NULL || el == NULL) {
    return 0;
  }
  
  // If the first element exists
  if (temp == el) {
    return 1;
  }
  
  while (temp != NULL) {
    if (temp == el) {
      return 1;
    }
    temp = temp->next;
  }
  return 0;
}

//*UPPGIFT 1c*//
void printList(Node *list) {
  if (list == NULL) {
    printf("The list is empty! \n");
    return;
  }
  Node *temp = list;
  while (temp != NULL) {
    printf("[id: %d], [sensorData: %f]\n", temp->time, temp->temperature);
    temp = temp->next;
  }
  return;
}

//*UPPGIFT 1d*//

void removes(Node **list, Node *el) {
  Node *prevNode = NULL;
  Node *currentNode = *list;
  Node *tempNode = *list;
  
  // All NULL or Element not found scenario
  if (isMember(list, el) == 0) 
    return;
  
  
  // Only one Element set it to NULL
  if (currentNode->next == NULL) {
    *list = NULL;
    return;
  }
  
  // two  or more elements
  while (currentNode != NULL) {
    // If we do not match go to next
    if (currentNode != el) {
      prevNode = currentNode;
      currentNode = currentNode->next;
      continue;
    }
    
    if (prevNode == NULL) { // First element to remove
      currentNode = currentNode->next;
      *list = currentNode;
      return;
    } else if (currentNode->next == NULL) { // Last element to remove
      prevNode->next = NULL;
      currentNode = NULL;
      return;
    } else { // Middle element to remove
      prevNode->next = currentNode->next;
      currentNode = NULL;
      return;
    }
  }
}

//*UPPGIFT 2*//
Node *readSensor(short time) {
  Node *p;
  p = createNode(time, (float)rand() / RAND_MAX);
  return p;
}

//*UPPGIFT 3*//
void NodeSort(Node** list){
  // Return if list is empty
  if (*list == NULL)
    return;
  
  Node *tempNode = *list;
  Node *currentNode = *list;
  Node *largestNode = NULL;
  
  // Loop through all elements
  while (currentNode != NULL) {
    // Give largestNode a newNode to start from
    largestNode = tempNode;

    //Loop to find the largest sensordata value in tempData
    while (tempNode != NULL) {
      // If SensorData from largestNode is smaller than tempNode's then make tempNode the largest
      if (largestNode->time < tempNode->time)
        largestNode = tempNode;
      tempNode = tempNode->next;
    }
    
    // Remove the largest from currentNode List
    removes(&currentNode,largestNode);
    // Also remove it from the proper list if it wasn't removed from the previous remove
    removes(list, largestNode);
    // Add new value to tempNode
    tempNode = currentNode;
    // we removed it from its position to now add it at the beginning
    insertFirst(list, largestNode);
  }
}

//*UPPGIFT 4*//
void clearMemory(Node **list) {
  Node *current = *list;
  Node *temp = NULL;
  
  if (*list == NULL) {
    printf("The list is empty! \n");
    return;
  }
  
  while (current != NULL) {
    temp = current->next;
    free(current);
    current = temp;
  }
  *list = NULL;
}

//*Find maximum value*//
Node *findMax(Node **list){
  if(*list == NULL){
    printf("The list is empty! \n");
    return NULL;
  }
  Node *tempNode = *list;
  Node *max = tempNode;
  while(tempNode != NULL){
      if(max->temperature < tempNode->temperature)
          max = tempNode;
      tempNode = tempNode->next;
  }
  return max;
}

//*Find minimum value*//
Node *findMin(Node **list){
    if(*list == NULL){
        printf("The list is empty! \n");
        return NULL;
    }
    Node *tempNode = *list;
    Node *min = tempNode;
    while(tempNode != NULL){
        if(min->temperature > tempNode->temperature)
            min = tempNode;
        tempNode = tempNode->next;
    }
    return min;
}

//*Find average value*//
double findAvg(Node **list){
    if(*list == NULL){
        printf("The list is empty! \n");
        return 0;
    }
    Node *tempNode = *list;
    double avg = 0;
    while(tempNode != NULL){
        avg += tempNode->temperature;
        tempNode = tempNode->next;
    }
    return avg/size(*list);
    }

char isFull(Node **list){
   Node *tempNode = (Node *)malloc(sizeof(Node));
   //If malloc() function returns NULL value then memory is full.
   
    if(tempNode == NULL)
        return 1;
    free(tempNode);
    return 0;
}

void insertFirst(Node **list, Node *el) {
    if(isFull(list) == 1){
        Node *tempNode = *list;
        while(tempNode->next != NULL)
            tempNode = tempNode->next;
        removes(list, tempNode);
        el->next = *list;
        *list = el;
        return;
    }
    // temp = *list; // Create a variable "temp" for the list
    // el->next = temp; // Put the "temp" list right next to the element we want
    // to insert.
    el->next = *list; // Put the "temp" list right next to the element we want to insert.
    *list = el; // The new list is now the element including the old list.
}

void timeh (char number, char pos){
  if(pos > 3)
    return;
  //Binary:  0000 0000 0000 0000
  //Time:     H    H    M    M
  //Position: 3    2    1    0
  time |= (number & 0x0F)<<(4 * pos);
}

int main(void){
  Node *list = NULL;
  srand(time(NULL)); // Use to randomize and update the numbers everytime you
  // run the program.
  // Insert adress of the pointer of the list by using "&list" in addNode
  // function.
  
  // insertFirst(&list, createNode(10, 10));
  // insertFirst(&list, createNode(9, 20));
  // insertFirst(&list, createNode(8, 30));
  // insertFirst(&list, createNode(7, 40));
  // insertFirst(&list, createNode(6, 50));
  // insertFirst(&list, createNode(5, 60));
  // insertFirst(&list, createNode(4, 70));
  
  Node *one = readSensor(1);
  Node *two = readSensor(2);
  Node *three = readSensor(3);
  Node *four = readSensor(4);
  Node *five = readSensor(5);
  Node *six = readSensor(6);
  Node *seven = readSensor(7);
  Node *eight = readSensor(8);
  Node *nine = readSensor(9);
  Node *ten = readSensor(10);
 // insertFirst(&list, ten);
 // insertFirst(&list, nine);
  //insertFirst(&list, eight);
  //insertFirst(&list, seven);
 // insertFirst(&list, six);
 // insertFirst(&list, five);
 //insertNode(&list, four);
 insertNode(&list, three);
 insertNode(&list, two);
 insertNode(&list, one);
 int x = 0;
 while(isFull(&list) != 1){
     Node* variable = readSensor(x);
     insertNode(&list, variable);
     x++;
 }
  
  printList(list);
  // printf("Is the element a member in the list?: %d \n",
  //       isMember(&list, *one));
  printf("Size: %d \n", size(list));
  //removes(&list, three);
  //removes(&list, two);
  //removes(&list, one);
  //NodeSort(&list);
  printf("Max: %f \n", findMax(&list)->temperature);
  printf("Min: %f \n", findMin(&list)->temperature);
  printf("Average: %f \n", findAvg(&list));
  printf("Is it full?: %d \n", isFull(&list));
  //insertFirst(&list, findMax(&list));
  //printList(list);
  //clearMemory(&list);
  //printList(list);
  //printf("Is the element a member in the list?: %s \n", (isMember(&list, createNode(1, 5)) ? "Yes":"No"));
  return 0;
}