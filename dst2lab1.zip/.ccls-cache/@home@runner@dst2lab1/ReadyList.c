#include "ReadyList.h"
#include <stdio.h>

typedef struct Node {
  void *data;
  struct Node *next;
  struct Node *prev;
}ReadyList, WaitingList, TimerList;