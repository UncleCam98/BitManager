#include "dateList.h"
#include "timeList.h"
#include "byte_manipulator.h"
#include <stdlib.h>
#include <stdio.h>

void insertFirst(struct date_Node **list, struct date_Node *el){
    if (*list == NULL){
        *list = el;
        return;
    }
    // temp = *list; // Create a variable "temp" for the list
    // el->next = temp; // Put the "temp" list right next to the element we want
    // to insert.
    el->next = *list; // Put the "temp" list right next to the element we want to insert.
    *list = el; // The new list is now the element including the old list.
}

struct date_Node *create_dateNode(struct date_Node **list, timeNode **dataNode, unsigned int id) {
  dateNode *p = NULL;
  p = (dateNode *)malloc(sizeof(dateNode));
  while (p == NULL) {
    dateNode *tempNode = *list;
    while(tempNode->next != NULL)
      tempNode = tempNode->next;
    clearMemory( tempNode->dataNode); //Clear all timeNodes in the oldest dateNode.
    Delete(list, tempNode); //Deleting the oldest dateNode.
    free(tempNode); //Free memory in the oldest dateNode.
    p = (dateNode *)malloc(sizeof(dateNode));
  }
  p->id = id; //Date
  p->dataNode = dataNode; //Node for time and temperature
  p->next = NULL;
  p->max = findMax(dataNode);
  p->min = findMin(dataNode);
  p->avg = findAvg(dataNode);
  return p;
  //“malloc” is used to dynamically allocate a single large block of memory with
  // the specified size. It returns a pointer of type void which can be cast
  // into a pointer of any form.
}

void Delete(struct date_Node **list, struct date_Node *el){
    dateNode *prevNode = NULL;
    dateNode *currentNode = *list;

    // ALL NULL or eller Element not found scenario
    if(isExist(list, el) == 0)
        return;

    //Only one element set it to NULL
    if(currentNode->next == NULL){
        *list = NULL;
        return;
    }

    // two  or more elements
    while (currentNode != NULL) {
        // If we do not match go to next
        if (currentNode != el) {
            prevNode = currentNode;
            currentNode = currentNode->next;
            continue;
        }

        if (prevNode == NULL) { // First element to remove
            currentNode = currentNode->next;
            *list = currentNode;
            return;
        } else if (currentNode->next == NULL) { // Last element to remove
            prevNode->next = NULL;
            currentNode = NULL;
            return;
        } else { // Middle element to remove
            prevNode->next = currentNode->next;
            currentNode = NULL;
            return;
        }
    }
}
int isExist(struct date_Node **list, struct date_Node *p){
    dateNode *temp = *list;
    if(*list == NULL || p == 0)
        return 0;
    if(temp == p)
        return 1;
    while(temp != NULL){
        if(temp == p)
            return 1;
        temp = temp->next;
    }
    return 0;
}

void Set_Value_2_Node(struct date_Node **list, struct date_Node *p){
    dateNode *tempNode = *list;
    /*if(p == NULL || p->dataNode == NULL || isExist(list, p) == 0){
        printf("The Node doesn't exist!");
        return;
    }*/
    while (tempNode != NULL) {
        if (isExist((dateNode **) &list, p) == 1) {
            p->min = findMin(p->dataNode);
            p->max = findMax(p->dataNode);
            p->avg = findAvg(p->dataNode);
            return;
        }
        tempNode = tempNode->next;
    }
  }

void printList(struct date_Node *list) {
    if (list == NULL) {
        printf("The list is empty! \n");
        return;
    }

    struct date_Node *temp = list;
    printf("DATE             Temp[MIN]        AVG       Temp[MAX]\n");
    while (temp != NULL) {
        //
        // DATE     Temp[MIN]   AVG   Temp[MAX]
        // ----------------------------------------
        // DD/MM/YYYY TTTT[hh:mm] TTTT  TTTT[hh:mm]
        // DD/MM/YYYY TTTT[hh:mm] TTTT  TTTT[hh:mm]
        printf("[%02d/%02d/%02d]    % 04d'c[%02d:%02d]    % 04d'c    % 04d'c[%02d:%02d]\n",
               Get_2_Bytes(&temp->id, 0), //DD
               Get_2_Bytes(&temp->id, 2), //MM
               Get_4_Bytes(&temp->id, 1), //YYYY
               Get_4_Signed_Bytes(&(temp->min),1), //Min temperature
               Get_2_Bytes(&(temp->min),0), //hh for min
               Get_2_Bytes(&(temp->min),2), //mm for min
               temp->avg, //Average temperature
               Get_4_Signed_Bytes(&(temp->max),1), //Max temperature
               Get_2_Bytes(&(temp->max),0), //hh for max
               Get_2_Bytes(&(temp->max),2) //mm for max
               );
        temp = temp->next;
    }
}
