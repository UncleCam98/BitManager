#include "timeList.h"
#include <stdlib.h>
#include <stdio.h>
#include "byte_manipulator.h"

void putFirst(struct time_Node **list, struct time_Node *el){
    if(*list == NULL){
        *list = el;
        return;
    }
    el->next = *list;
    *list = el;
}


struct time_Node *create_timeNode(struct time_Node **list, unsigned int id) {
  timeNode *p = NULL;
  p = (timeNode *)malloc(sizeof(timeNode));
  while (p == NULL) {
    timeNode *tempNode = *list;
    while(tempNode->next != NULL)
      tempNode = (timeNode *) tempNode->next;
    disconnect(list, tempNode);
    free(tempNode);
    p = (timeNode *)malloc(sizeof(timeNode));
  }
  p->id = id; //  timestamp_temp - hhmmTTTT - 15200021
  p->next = NULL;
  return p;
  //“malloc” is used to dynamically allocate a single large block of memory with
  // the specified size. It returns a pointer of type void which can be cast
  // into a pointer of any form.
}

void disconnect(struct time_Node **list, struct time_Node *el){
    timeNode *prevNode = NULL;
    timeNode *currentNode = *list;

    if(isMember(list, el) == 0)
        return;

    if(currentNode->next == NULL){
        *list = NULL;
        return;
    }

    // two  or more elements
    while (currentNode != NULL) {
        // If we do not match go to next
        if (currentNode != el) {
            prevNode = currentNode;
            currentNode = currentNode->next;
            continue;
        }

        if (prevNode == NULL) { // First element to remove
            currentNode = currentNode->next;
            *list = currentNode;
            return;
        } else if (currentNode->next == NULL) { // Last element to remove
            prevNode->next = NULL;
            currentNode = NULL;
            return;
        } else { // Middle element to remove
            prevNode->next = currentNode->next;
            currentNode = NULL;
            return;
        }
    }
}

int isMember(struct time_Node **list, struct time_Node *el){
    timeNode *temp = *list;
    if(*list == NULL || el == NULL)
        return 0;

    if(temp == el)
        return 1;

    while(temp != NULL){
        if(temp == el)
            return 1;
        temp = temp->next;
    }
    return 0;
}

int size(timeNode *list) {
    int counter = 0;
    timeNode *temp = list;
    while (temp != NULL) {
        counter++;
        temp = temp->next;
    }
    return counter;
}


short findAvg(timeNode **list){
    if(*list == NULL){
        printf("The list is empty! \n");
        return 0;
    }
    timeNode *tempNode = *list;
    double avg = 0;
    while(tempNode != NULL){
        avg += Get_4_Signed_Bytes(&(tempNode->id), 1);
        tempNode = tempNode->next;
    }
    return avg/size(*list);
}

unsigned int findMax(timeNode **list){
    if(*list == NULL){
        printf("The list is empty! \n");
        return 0;
    }
    timeNode *tempNode = *list;
    timeNode *max = tempNode;
    while(tempNode != NULL){
        if(Get_4_Signed_Bytes(&(max->id), 1) < Get_4_Signed_Bytes(&(tempNode->id), 1))
            max = tempNode;
        tempNode = tempNode->next;
    }
    return (max->id);
}

unsigned int findMin(timeNode **list){
    if(*list == NULL){
        printf("The list is empty! \n");
        return 0;
    }
    timeNode *tempNode = *list;
    timeNode *min = tempNode;
    while(tempNode != NULL){

        if(Get_4_Signed_Bytes(&(min->id), 1) > Get_4_Signed_Bytes(&(tempNode->id), 1))
            min = tempNode;
        tempNode = tempNode->next;
    }
    return min->id;
}

void listPrint(struct time_Node *list){
    if (list == NULL) {
        printf("The list is empty! \n");
        return;
    }
    struct time_Node *temp = list;
    while (temp != NULL) {
        printf("[time: %d],\n", temp->id);
        temp = temp->next;
    }
}

double getValue(timeNode* el){
    if(el == NULL)
        return 0;
    return Get_4_Bytes(&(el->id), 1);
}

double getNode(struct time_Node **list, int number){
    timeNode *value = NULL;
    timeNode *temp = *list;
    if (*list == NULL) {
        return 0;
    }
    for(int i = 0; i<number; i++){
        value = temp;
        temp = temp->next;
    }
   return Get_4_Bytes(&(value->id), 1);
}

void clearMemory(struct time_Node **list) {
    struct time_Node *current = *list;
    struct time_Node *temp = NULL;

    if (*list == NULL) {
        printf("The list is empty! \n");
        return;
    }

    while (current != NULL) {
        temp = current->next;
        free(current);
        current = temp;
    }
    *list = NULL;
}
