#ifndef TIMELIST_H
  #define TIMELIST_H

    //Functions
    struct time_Node *create_timeNode(struct time_Node **list, unsigned int id);
    void disconnect(struct time_Node **list, struct time_Node *el);
    double getValue(struct time_Node  *el);
    unsigned int findMin(struct time_Node **list);
    unsigned int findMax(struct time_Node **list);
    short findAvg(struct time_Node **list);
    int isMember(struct time_Node **list, struct time_Node *el);
    void putFirst(struct time_Node **list, struct time_Node *el);
    void listPrint(struct time_Node *list);
    void clearMemory(struct time_Node **list);
    double getNode(struct time_Node **list, int number);

        typedef struct time_Node{
          unsigned int id; // timestamp_temp - hhmmTTTT - 15200021
          struct time_Node *next; // pointer to the next element
    }timeNode;

#endif