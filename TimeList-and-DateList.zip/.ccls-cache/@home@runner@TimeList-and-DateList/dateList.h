#ifndef DATELIST_H
  #define DATELIST_H

#include "timeList.h"

struct date_Node *create_dateNode(struct date_Node **list, struct time_Node **dataNode, unsigned int id );
void insertFirst(struct date_Node **list, struct date_Node *el);
void Delete(struct date_Node **list, struct date_Node *el);
int isExist(struct date_Node **list, struct date_Node *p);
void printList(struct date_Node *list);
void Set_Value_2_Node(struct date_Node **list, struct date_Node *p);

        typedef struct date_Node {
    unsigned int id; // date DDMMYYYY
    unsigned int max; // hhmmTTTT
    unsigned int min;
    short avg;
    struct time_Node **dataNode; //Node for time and temperature
    struct date_Node *next; // pointer to the next element
  }dateNode;
  

#endif