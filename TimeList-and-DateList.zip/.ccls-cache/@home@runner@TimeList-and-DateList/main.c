#include "byte_manipulator.h"
#include "dateList.h"
#include "timeList.h"
#include <stdio.h>
#include <stdlib.h>

int main(void) {
  // Sätt in värdena med enbart datelist
  dateNode *dateList10 = NULL;
  timeNode *timeList10 = NULL;

  // Skapa en lista av noder per dag och sätt in en timelist per nod.
  for (int x = 0; x < 7; x++) {
    // Skapa en lista med noder (timelist).
    for (int y = 0; y < 1440; y++) // Per minute
      putFirst(&timeList10, create_timeNode(&timeList10, y));
    // Per day
    insertFirst(&dateList10,
                create_dateNode(&dateList10, &timeList10, 0x01122022));
  }
  printList(((dateNode *)dateList10));

  // Hämta ut värdena med enbart datelist
  dateNode *temp = dateList10;
  while (temp->next != NULL) {
    printf("ID: %02x \n", temp->id);
    printf("Min: %02d \n", Get_4_Signed_Bytes(&(temp->min), 1));
    printf("Time: %02d:%02d \n", Get_2_Bytes(&(temp->min), 0), // hh for min
           Get_2_Bytes(&(temp->min), 2));                      // mm for min
    printf("Max: %02d \n", Get_4_Signed_Bytes(&(temp->max), 1));
    printf("Time: %02d:%02d \n", Get_2_Bytes(&(temp->max), 0), // hh for max
           Get_2_Bytes(&(temp->max), 2));                      // mm for max
    printf("Avg: % 02d \n", temp->avg);
    temp = temp->next;
  }
  return 0;
}