#include "main.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct Node {
    int id; // data
    double sensorData;
    struct Node *next; // pointer to the next element
};

int size(struct Node *list) {
  int counter = 0;
  struct Node *temp = list;
  while (temp != NULL) {
    counter++;
    temp = temp->next;
  }
  return counter;
}

struct Node *createNode(int id, double sensorData) {
  struct Node *p = NULL;
  p = (struct Node *)malloc(sizeof(struct Node));
  if (p == NULL) {
    printf("Out of memory ! \n");
    return NULL;
  }
  p->id = id;
  p->sensorData = sensorData;
  p->next = NULL;
  return p;
  //“malloc” is used to dynamically allocate a single large block of memory with
  // the specified size. It returns a pointer of type void which can be cast
  // into a pointer of any form.
}

//*UPPGIFT 1a*//
void insertFirst(struct Node **list, struct Node *el) {
  if (*list == NULL) {
    *list = el;
    return;
  }
  // temp = *list; // Create a variable "temp" for the list
  // el->next = temp; // Put the "temp" list right next to the element we want
  // to insert.
  el->next = *list; // Put the "temp" list right next to the element we want to insert.
  *list = el; // The new list is now the element including the old list.
}

//*UPPGIFT 1b*//
int isMember(struct Node **list, struct Node *el) {
  struct Node *temp = *list;
  if (*list == NULL || el == NULL) {
    return 0;
  }
  
  // If the first element exists
  if (temp == el) {
    return 1;
  }
  
  while (temp != NULL) {
    if (temp == el) {
      return 1;
    }
    temp = temp->next;
  }
  return 0;
}

//*UPPGIFT 1c*//
void listPrint(struct Node *list) {
  if (list == NULL) {
    printf("The list is empty! \n");
    return;
  }
  struct Node *temp = list;
  while (temp != NULL) {
    printf("[id: %d], [sensorData: %f]\n", temp->id, temp->sensorData);
    temp = temp->next;
  }
  return;
}

//*UPPGIFT 1d*//

void removes(struct Node **list, struct Node *el) {
  struct Node *prevNode = NULL;
  struct Node *currentNode = *list;
  struct Node *tempNode = *list;
  
  // All NULL or Element not found scenario
  if (isMember(list, el) == 0) 
    return;
  
  
  // Only one Element set it to NULL
  if (currentNode->next == NULL) {
    *list = NULL;
    return;
  }
  
  // two  or more elements
  while (currentNode != NULL) {
    // If we do not match go to next
    if (currentNode != el) {
      prevNode = currentNode;
      currentNode = currentNode->next;
      continue;
    }
    
    if (prevNode == NULL) { // First element to remove
      currentNode = currentNode->next;
      *list = currentNode;
      return;
    } else if (currentNode->next == NULL) { // Last element to remove
      prevNode->next = NULL;
      currentNode = NULL;
      return;
    } else { // Middle element to remove
      prevNode->next = currentNode->next;
      currentNode = NULL;
      return;
    }
  }
}

//*UPPGIFT 2*//
struct Node *readSensor(int id) {
  struct Node *p;
  p = createNode(id, (float)rand() / RAND_MAX);
  return p;
}

//*UPPGIFT 3*//
void NodeSort(struct Node** list){
  // Return if list is empty
  if (*list == NULL)
    return;
  
  struct Node *tempNode = *list;
  struct Node *currentNode = *list;
  struct Node *largestNode = NULL;
  
  // Loop through all elements
  while (currentNode != NULL) {
    // Give largestNode a new node to start from
    largestNode = tempNode;
    
    //Loop to find the largest sensordata value in tempData
    while (tempNode != NULL) {
      // If SensorData from largestNode is smaller than tempNode's then make tempNode the largest
      if (largestNode->sensorData < tempNode->sensorData)
        largestNode = tempNode;
      tempNode = tempNode->next;
    }
    
    // Remove the largest from currentNode List
    removes(&currentNode,largestNode);
    // Also remove it from the proper list if it wasn't removed from the previous remove
    removes(list, largestNode);
    // Add new value to tempNode
    tempNode = currentNode;
    // we removed it from its position to now add it at the beginning
    insertFirst(list, largestNode);
  }
}

//*UPPGIFT 4*//
void clearMemory(struct Node **list) {
  struct Node *current = *list;
  struct Node *temp = NULL;
  
  if (*list == NULL) {
    printf("The list is empty! \n");
    return;
  }
  
  while (current != NULL) {
    temp = current->next;
    free(current);
    current = temp;
  }
  *list = NULL;
}

//*Find max value*//
struct Node *findMax(struct Node **list){
  if(*list == NULL){
    printf("The list is empty! \n");
    return NULL;
  }
  return NULL;
}

int main(void) {
  struct Node *list = NULL;
  srand(time(NULL)); // Use to randomize and update the numbers everytime you
  // run the program.
  // Insert adress of the pointer of the list by using "&list" in addNode
  // function.
  
  // insertFirst(&list, createNode(10, 10));
  // insertFirst(&list, createNode(9, 20));
  // insertFirst(&list, createNode(8, 30));
  // insertFirst(&list, createNode(7, 40));
  // insertFirst(&list, createNode(6, 50));
  // insertFirst(&list, createNode(5, 60));
  // insertFirst(&list, createNode(4, 70));
  
  struct Node *one = readSensor(1);
  struct Node *two = readSensor(2);
  struct Node *three = readSensor(3);
  struct Node *four = readSensor(4);
  struct Node *five = readSensor(5);
  struct Node *six = readSensor(6);
  struct Node *seven = readSensor(7);
  struct Node *eight = readSensor(8);
  struct Node *nine = readSensor(9);
  struct Node *ten = readSensor(10);
  insertFirst(&list, ten);
  insertFirst(&list, nine);
  insertFirst(&list, eight);
  insertFirst(&list, seven);
  insertFirst(&list, six);
  insertFirst(&list, five);
  insertFirst(&list, four);
  insertFirst(&list, three);
  insertFirst(&list, two);
  insertFirst(&list, one);
  
  printList(list);
  // printf("Is the element a member in the list?: %d \n",
  //       isMember(&list, *one));
  printf("Size: %d \n", size(list));
  //removes(&list, three);
  //removes(&list, two);
  //removes(&list, one);
  NodeSort(&list);
  printList(list);
  clearMemory(&list);
  printList(list);
  printf("Is the element a member in the list?: %s \n", (isMember(&list, createNode(1, 5)) ? "Yes": "No"));
  return 0;
}