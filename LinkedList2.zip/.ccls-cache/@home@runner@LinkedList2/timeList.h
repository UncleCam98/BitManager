#ifndef TIMELIST_H
  #define TIMELIST_H
  
  typedef struct time_Node {
      // short time; (binärt 4 hexa 0x0000 -> 0xhhmm) (1 << 12) [s  = 0000 0001 0000 0100 = 01:04]
      // (time >> 4) 0xf
      int id; // date
      double data;
      struct Node *next; // pointer to the next element
  }timeNode;
  

#endif