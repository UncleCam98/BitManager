#ifndef DATELIST_H
  #define DATELIST_H
  
  typedef struct date_Node {
      // short time; (binärt 4 hexa 0x0000 -> 0xhhmm) (1 << 12) 
      // [s  = 0000 0001   0000 0100 = 01:04]
      // (time >> 4) 0xf
      unsigned int date; // date
      short data;
      struct timeNode *dataNode;
      struct dateNode *next; // pointer to the next element
  }dateNode;
  

#endif