#include "dateList.h"
#include "timeList.h"
dateNode *create_dateNode(dateNode **list, timeNode *dataNode, unsigned int id ) {
  dateNode *p = NULL;
  p = (dateNode *)malloc(sizeof(dateNode));
  while (p == NULL) {
    dateNode *tempNode = *list;
    while(tempNode->next != NULL)
      tempNode = tempNode->next;
    removes(list, tempNode);
    free(tempNode);
    p = (dateNode *)malloc(sizeof(dateNode));
  }
  p->id = id;
  p->dataNode = dataNode;
  p->next = NULL;
  return p;
  //“malloc” is used to dynamically allocate a single large block of memory with
  // the specified size. It returns a pointer of type void which can be cast
  // into a pointer of any form.
}

void removes(dateNode **list, dateNode *el) {
  dateNode *prevNode = NULL;
  dateNode *currentNode = *list;
  dateNode *tempNode = *list;
  
  // All NULL or Element not found scenario
  if (isMember(list, el) == 0) 
    return;
  
  // Only one Element set it to NULL
  if (currentNode->next == NULL) {
    *list = NULL;
    return;
    }
  }

void Set_Value_2_Node(dateNode *p, double value){
  *p->dataNode->data = value;
  return;
}

int main(void){
  return 0;
  }
