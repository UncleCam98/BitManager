#include "timeList.h"
timeNode *create_timeNode(Node **list, unsigned char id, short data) {
  timeNode *p = NULL;
  p = (timeNode *)malloc(sizeof(timeNode));
  while (p == NULL) {
    timeNode *tempNode = *list;
    while(tempNode->next != NULL)
      tempNode = tempNode->next;
    removes(list, tempNode);
    free(tempNode);
    p = (timeNode *)malloc(sizeof(timeNode));
  }
  p->id = id;
  p->data = data;
  p->next = NULL;
  return p;
  //“malloc” is used to dynamically allocate a single large block of memory with
  // the specified size. It returns a pointer of type void which can be cast
  // into a pointer of any form.
}